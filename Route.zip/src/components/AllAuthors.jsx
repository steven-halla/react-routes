import React from 'react';

const AllAuthors = () => {

    return(
        <div>
            <h3> Welcome </h3>
        </div>
    )
}

export default AllAuthors;